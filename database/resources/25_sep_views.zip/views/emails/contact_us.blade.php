
Dear {{ $name }}

<p>{{$contact_us}}</p>

<p style="color: black;">If you face any problem or if you have any suggestion for our developments, please write back - <a href="mailto:support@belaobela.com.bd">support@belaobela.com.bd</a></p>
<p style="color: black;">Anything anywhere anytime, stay with us as your trusted partner.</p>
<p style="color: black;">Thanks <br><br>BelaObela<br>Concord Tower; Suit no: 1401,<br>113 Kazi Nazrul Islam Avenue,<br>Ramna, Dhaka<br>Phone +88-02-41031891<br>For Sales Inquiry +88-01870-728000<br>For Service Inquiry +88-01870-728001<br>For Delivery Support +88-01870-728002<br> </p>
<p style="margin-top:10px; color: black;"><span style="font-weight:700"><u>Caution:</u></span> Please do not print this email unnecessarily. Save paper, save Environment and live green. Do not click links or open attachments unless you recognize the sender and know the content is safe.</p>
<p style="margin-top:10px; color: black;"><span style="font-weight:700"><u>Disclaimer:</u></span> This email, including any attachment with it, may contain privileged, proprietary &amp; confidential information and is intended solely for the addressee. If you are not the intended recipient of this email, please notify us immediately and destroy this email without taking any copies or showing it to anyone. The unauthorized use of this email is prohibited. BELAOBELA will not take any responsibility for misdirection, corruption, or unauthorized use of e-mail communications, or for any damage that may be caused as a result of transmitting or receiving an email communication.</p>
